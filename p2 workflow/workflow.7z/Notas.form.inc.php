Nombre:
<input type="text" value="<?php echo $nombre;?>" name="nombre"/>
<br/>
Usted debe presentar:<br>
-CI