<?php
$conn=mysqli_connect("localhost","usuario","123456");
mysqli_select_db($conn,"workflow");
?>