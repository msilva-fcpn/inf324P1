<html>
	<head>
		<title>FCPN</title>
	</head>
	<body>
		<h1>Mi formulario</h1>
		<form method="GET" action="http://localhost:20366/Default.aspx">
			Nombre
			<input type="text" name="nombre" value=""><br>
			Apellido
			<input type="text" name="apellido" value=""><br>
			<input type="submit" name="enviar" value="Enviar">
			<input type="submit" name="cancelar" value="Cancelar"><br>
		</form>
	</body>
</html>