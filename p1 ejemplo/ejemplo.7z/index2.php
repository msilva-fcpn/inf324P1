<html>
	<head>
		<title>FCPN</title>
		<link href="miestilo.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<div id="cabecera">
			<div style="width:100;heigth:100;float:left">
				<img style="width:100;heigth:100;" src="índice.png"/>
			</div>
			<div style="width:500;heigth:100;float:left">
				<h1 style="">Universidad Mayor de San Andres</h1>
				<h2>Facultad de Ciencias Puras y Naturales</h2>
			</div>
		</div>
		<div class="menu">
		menu
		</div>
		<div class="cuerpo">
		cuerpo
		mi primera pagina
		
		</div>
	</body>
</html>