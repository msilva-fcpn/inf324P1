<?php include "cabecera.inc.php"; ?>
		cuerpo
		mi segunda pagina
		dadsadsadsa
		
<?php include "pie.inc.php"; ?>