<html>
	<head>
		<title>FCPN</title>
	</head>
	<body>
		<?php
			echo "Facultad de Ciencias Puras y Naturales";
			echo '<br>';
			echo 1990;
			echo '<table border="1px">';
			echo '<tr>';
			echo '<td>numero</td><td>descripcion</td>';
			echo '</tr>';
			$numero = 1;
		?>
<tr>
<td><?php echo $numero; $numero=$numero+1;?></td>
<td>uno</td>
</tr>
<tr>
<td><?php echo $numero; ?></td>
<td>dos</td>
</tr>
		<?php
			echo '</table>';
		?>
		<div style="width:400;heigth:200;">
			<p style="color:#9b2e16;background:#f7f68e">Hola mundo mundiales</p>
		</div>
	</body>
</html>